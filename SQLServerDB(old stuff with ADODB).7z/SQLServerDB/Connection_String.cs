﻿using System;


namespace SQLServerDB
{
    public class Connection_String
    {
        public static string SQLServer_ConnectionString { get; set; }

        public static string ADO_ConnectionString { get; set; }

    }//class Connection_String

    }//namespace
